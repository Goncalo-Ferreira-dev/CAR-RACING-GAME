﻿Public Class Form1
    Dim speed As Integer
    Dim road(7) As PictureBox
    Dim score As Integer = 0
    Dim direction As Single
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        speed = 3
        road(0) = PictureBox1
        road(1) = PictureBox2
        road(2) = PictureBox3
        road(3) = PictureBox4
        road(4) = PictureBox5
        road(5) = PictureBox6
        road(6) = PictureBox7
        road(7) = PictureBox8
        RoadMover.Stop()
        RacerMover1.Stop()
        RacerMover2.Stop()
        RacerMover3.Stop()
    End Sub

    Private Sub RoadMover_Tick(sender As Object, e As EventArgs) Handles RoadMover.Tick
        For x As Integer = 0 To 7
            road(x).Top += speed
            If road(x).Top >= Me.Height Then
                road(x).Top = -road(x).Height
            End If
        Next

        If (score > 10 And score < 30) Then
            speed = 5
        End If
        If (score > 30 And score < 50) Then
            speed = 6
        End If
        If (score > 50 And score < 70) Then
            speed = 7
        End If
        If (score > 100) Then
            speed = 9
        End If

        Label2.Text = "Speed: " & speed

        If (CarroJogador.Bounds.IntersectsWith(racer1.Bounds)) Then
            endgame()
        End If
        If (CarroJogador.Bounds.IntersectsWith(racer2.Bounds)) Then
            endgame()
        End If
        If (CarroJogador.Bounds.IntersectsWith(racer3.Bounds)) Then
            endgame()
        End If
    End Sub

    Private Sub endgame()
        Button1.Visible = True
        Label3.Visible = True
        RoadMover.Stop()
        RacerMover1.Stop()
        RacerMover2.Stop()
        RacerMover3.Stop()
    End Sub

    Private Sub Form1_KeyDown(sender As Object, e As KeyEventArgs) Handles MyBase.KeyDown
        If e.KeyCode = Keys.D Then
            RightSide.Start()
        End If
        If e.KeyCode = Keys.A Then
            LeftSide.Start()
        End If
        If e.KeyCode = Keys.W Then
            TopSide.Start()
        End If
        If e.KeyCode = Keys.S Then
            DownSide.Start()
        End If
    End Sub

    Private Sub RightSide_Tick(sender As Object, e As EventArgs) Handles RightSide.Tick
        If (CarroJogador.Location.X < 295) Then
            CarroJogador.Left += 5
        End If
    End Sub

    Private Sub LeftSide_Tick(sender As Object, e As EventArgs) Handles LeftSide.Tick
        If (CarroJogador.Location.X > 0) Then
            CarroJogador.Left -= 5
        End If
    End Sub
    Private Sub TopSide_Tick(sender As Object, e As EventArgs) Handles TopSide.Tick
        If (CarroJogador.Location.Y > 0) Then
            CarroJogador.Top -= 5
        End If
    End Sub
    Private Sub DownSide_Tick(sender As Object, e As EventArgs) Handles DownSide.Tick
        If (CarroJogador.Location.Y < 375) Then
            CarroJogador.Top += 5
        End If
    End Sub

    Private Sub Form1_KeyUp(sender As Object, e As KeyEventArgs) Handles MyBase.KeyUp
        RightSide.Stop()
        LeftSide.Stop()
        TopSide.Stop()
        DownSide.Stop()
    End Sub

    Private Sub RacerMover1_Tick(sender As Object, e As EventArgs) Handles RacerMover1.Tick
        racer1.Top += speed / 2
        'If (racer1.Location.X > 0) Then
        'racer1.Left -= speed / 3
        'End If
        'If (racer1.Location.X < 295) Then
        'racer1.Left += speed / 3
        'End If
        If racer1.Top >= Me.Height Then
            score += 1
            Label1.Text = "Score: " & score

            racer1.Top = -(CInt(Math.Ceiling(Rnd() * 200)) + racer1.Height)
            racer1.Left = (CInt(Math.Ceiling(Rnd() * 50))) + 0
        End If
    End Sub

    Private Sub RacerMover2_Tick(sender As Object, e As EventArgs) Handles RacerMover2.Tick
        racer2.Top += speed / 3
        If racer2.Top >= Me.Height Then
            score += 1
            Label1.Text = "Score: " & score

            racer2.Top = -(CInt(Math.Ceiling(Rnd() * 200)) + racer2.Height)
            racer2.Left = (CInt(Math.Ceiling(Rnd() * 50))) + 100
        End If
    End Sub

    Private Sub RacerMover3_Tick(sender As Object, e As EventArgs) Handles RacerMover3.Tick
        racer3.Top += speed * 1 / 2
        If racer3.Top >= Me.Height Then
            score += 1
            Label1.Text = "Score: " & score

            racer3.Top = -(CInt(Math.Ceiling(Rnd() * 200)) + racer3.Height)
            racer3.Left = (CInt(Math.Ceiling(Rnd() * 120))) + 180
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        score = 0
        Controls.Clear()
        InitializeComponent()
        Form1_Load(e, e)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        score = 0
        Controls.Clear()
        InitializeComponent()
        Form1_Load(e, e)
        Button2.Visible = False
        Label4.Visible = False
        RoadMover.Start()
        RacerMover1.Start()
        RacerMover2.Start()
        RacerMover3.Start()
    End Sub
End Class
