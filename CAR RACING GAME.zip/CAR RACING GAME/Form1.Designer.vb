﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        components = New ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        PictureBox2 = New PictureBox()
        PictureBox1 = New PictureBox()
        PictureBox3 = New PictureBox()
        PictureBox4 = New PictureBox()
        PictureBox5 = New PictureBox()
        PictureBox6 = New PictureBox()
        PictureBox7 = New PictureBox()
        PictureBox8 = New PictureBox()
        Label1 = New Label()
        Label2 = New Label()
        racer1 = New PictureBox()
        racer3 = New PictureBox()
        racer2 = New PictureBox()
        CarroJogador = New PictureBox()
        RoadMover = New Timer(components)
        RightSide = New Timer(components)
        LeftSide = New Timer(components)
        RacerMover1 = New Timer(components)
        RacerMover2 = New Timer(components)
        RacerMover3 = New Timer(components)
        Label3 = New Label()
        Button1 = New Button()
        Label4 = New Label()
        Button2 = New Button()
        TopSide = New Timer(components)
        DownSide = New Timer(components)
        TimerLado1 = New Timer(components)
        TimerLado2 = New Timer(components)
        TimerLado3 = New Timer(components)
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).BeginInit()
        CType(racer1, ComponentModel.ISupportInitialize).BeginInit()
        CType(racer3, ComponentModel.ISupportInitialize).BeginInit()
        CType(racer2, ComponentModel.ISupportInitialize).BeginInit()
        CType(CarroJogador, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackColor = SystemColors.ButtonHighlight
        PictureBox2.Location = New Point(217, -45)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(12, 104)
        PictureBox2.TabIndex = 1
        PictureBox2.TabStop = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = SystemColors.ButtonHighlight
        PictureBox1.Location = New Point(106, -45)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(12, 104)
        PictureBox1.TabIndex = 2
        PictureBox1.TabStop = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.BackColor = SystemColors.ButtonHighlight
        PictureBox3.Location = New Point(106, 111)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(12, 104)
        PictureBox3.TabIndex = 4
        PictureBox3.TabStop = False
        ' 
        ' PictureBox4
        ' 
        PictureBox4.BackColor = SystemColors.ButtonHighlight
        PictureBox4.Location = New Point(217, 111)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(12, 104)
        PictureBox4.TabIndex = 3
        PictureBox4.TabStop = False
        ' 
        ' PictureBox5
        ' 
        PictureBox5.BackColor = SystemColors.ButtonHighlight
        PictureBox5.Location = New Point(106, 268)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(12, 104)
        PictureBox5.TabIndex = 6
        PictureBox5.TabStop = False
        ' 
        ' PictureBox6
        ' 
        PictureBox6.BackColor = SystemColors.ButtonHighlight
        PictureBox6.Location = New Point(217, 268)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(12, 104)
        PictureBox6.TabIndex = 5
        PictureBox6.TabStop = False
        ' 
        ' PictureBox7
        ' 
        PictureBox7.BackColor = SystemColors.ButtonHighlight
        PictureBox7.Location = New Point(106, 418)
        PictureBox7.Name = "PictureBox7"
        PictureBox7.Size = New Size(12, 104)
        PictureBox7.TabIndex = 8
        PictureBox7.TabStop = False
        ' 
        ' PictureBox8
        ' 
        PictureBox8.BackColor = SystemColors.ButtonHighlight
        PictureBox8.Location = New Point(217, 418)
        PictureBox8.Name = "PictureBox8"
        PictureBox8.Size = New Size(12, 104)
        PictureBox8.TabIndex = 7
        PictureBox8.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.Font = New Font("Agency FB", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.ForeColor = SystemColors.ButtonHighlight
        Label1.Location = New Point(21, 14)
        Label1.Name = "Label1"
        Label1.Size = New Size(65, 25)
        Label1.TabIndex = 9
        Label1.Text = "Score: 0"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("Agency FB", 15.75F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label2.ForeColor = SystemColors.ButtonHighlight
        Label2.Location = New Point(247, 14)
        Label2.Name = "Label2"
        Label2.Size = New Size(66, 25)
        Label2.TabIndex = 10
        Label2.Text = "Speed: 0"
        ' 
        ' racer1
        ' 
        racer1.Image = CType(resources.GetObject("racer1.Image"), Image)
        racer1.Location = New Point(27, 195)
        racer1.Name = "racer1"
        racer1.Size = New Size(53, 91)
        racer1.SizeMode = PictureBoxSizeMode.StretchImage
        racer1.TabIndex = 11
        racer1.TabStop = False
        ' 
        ' racer3
        ' 
        racer3.Image = My.Resources.Resources.carro3
        racer3.Location = New Point(256, 195)
        racer3.Name = "racer3"
        racer3.Size = New Size(53, 91)
        racer3.SizeMode = PictureBoxSizeMode.StretchImage
        racer3.TabIndex = 12
        racer3.TabStop = False
        ' 
        ' racer2
        ' 
        racer2.Image = My.Resources.Resources.carro2
        racer2.Location = New Point(143, 58)
        racer2.Name = "racer2"
        racer2.Size = New Size(53, 91)
        racer2.SizeMode = PictureBoxSizeMode.StretchImage
        racer2.TabIndex = 13
        racer2.TabStop = False
        ' 
        ' CarroJogador
        ' 
        CarroJogador.Image = CType(resources.GetObject("CarroJogador.Image"), Image)
        CarroJogador.Location = New Point(143, 337)
        CarroJogador.Name = "CarroJogador"
        CarroJogador.Size = New Size(53, 91)
        CarroJogador.SizeMode = PictureBoxSizeMode.StretchImage
        CarroJogador.TabIndex = 14
        CarroJogador.TabStop = False
        ' 
        ' RoadMover
        ' 
        RoadMover.Enabled = True
        RoadMover.Interval = 10
        ' 
        ' RightSide
        ' 
        RightSide.Interval = 10
        ' 
        ' LeftSide
        ' 
        LeftSide.Interval = 10
        ' 
        ' RacerMover1
        ' 
        RacerMover1.Enabled = True
        RacerMover1.Interval = 10
        ' 
        ' RacerMover2
        ' 
        RacerMover2.Enabled = True
        RacerMover2.Interval = 10
        ' 
        ' RacerMover3
        ' 
        RacerMover3.Enabled = True
        RacerMover3.Interval = 10
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = SystemColors.ButtonHighlight
        Label3.Font = New Font("Agency FB", 36F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label3.ForeColor = Color.Firebrick
        Label3.Location = New Point(68, 171)
        Label3.Name = "Label3"
        Label3.Size = New Size(197, 59)
        Label3.TabIndex = 15
        Label3.Text = "GAME OVER"
        Label3.Visible = False
        ' 
        ' Button1
        ' 
        Button1.BackColor = Color.PeachPuff
        Button1.BackgroundImageLayout = ImageLayout.None
        Button1.Font = New Font("Agency FB", 24F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button1.ForeColor = SystemColors.WindowText
        Button1.Location = New Point(114, 250)
        Button1.Name = "Button1"
        Button1.Size = New Size(108, 47)
        Button1.TabIndex = 16
        Button1.Text = "REPLAY"
        Button1.UseVisualStyleBackColor = False
        Button1.Visible = False
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.Gold
        Label4.Font = New Font("Agency FB", 36F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label4.ForeColor = Color.Black
        Label4.Location = New Point(68, 171)
        Label4.Name = "Label4"
        Label4.Size = New Size(214, 59)
        Label4.TabIndex = 17
        Label4.Text = "START GAME"
        ' 
        ' Button2
        ' 
        Button2.BackColor = Color.PeachPuff
        Button2.BackgroundImageLayout = ImageLayout.None
        Button2.Font = New Font("Agency FB", 24F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Button2.ForeColor = SystemColors.WindowText
        Button2.Location = New Point(114, 250)
        Button2.Name = "Button2"
        Button2.Size = New Size(108, 47)
        Button2.TabIndex = 18
        Button2.Text = "START"
        Button2.UseVisualStyleBackColor = False
        ' 
        ' TopSide
        ' 
        TopSide.Interval = 10
        ' 
        ' DownSide
        ' 
        DownSide.Interval = 10
        ' 
        ' TimerLado1
        ' 
        TimerLado1.Interval = 3500
        ' 
        ' TimerLado2
        ' 
        TimerLado2.Interval = 3000
        ' 
        ' TimerLado3
        ' 
        TimerLado3.Interval = 2500
        ' 
        ' Form1
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.ControlDarkDark
        ClientSize = New Size(334, 461)
        Controls.Add(Button2)
        Controls.Add(Label4)
        Controls.Add(Button1)
        Controls.Add(Label3)
        Controls.Add(CarroJogador)
        Controls.Add(racer2)
        Controls.Add(racer3)
        Controls.Add(racer1)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(PictureBox7)
        Controls.Add(PictureBox8)
        Controls.Add(PictureBox5)
        Controls.Add(PictureBox6)
        Controls.Add(PictureBox3)
        Controls.Add(PictureBox4)
        Controls.Add(PictureBox1)
        Controls.Add(PictureBox2)
        MaximumSize = New Size(350, 500)
        MinimumSize = New Size(350, 500)
        Name = "Form1"
        Text = "CAR RACING GAME"
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox8, ComponentModel.ISupportInitialize).EndInit()
        CType(racer1, ComponentModel.ISupportInitialize).EndInit()
        CType(racer3, ComponentModel.ISupportInitialize).EndInit()
        CType(racer2, ComponentModel.ISupportInitialize).EndInit()
        CType(CarroJogador, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents racer1 As PictureBox
    Friend WithEvents racer3 As PictureBox
    Friend WithEvents racer2 As PictureBox
    Friend WithEvents CarroJogador As PictureBox
    Friend WithEvents RoadMover As Timer
    Friend WithEvents RightSide As Timer
    Friend WithEvents LeftSide As Timer
    Friend WithEvents RacerMover1 As Timer
    Friend WithEvents RacerMover2 As Timer
    Friend WithEvents RacerMover3 As Timer
    Friend WithEvents Label3 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents TopSide As Timer
    Friend WithEvents DownSide As Timer
    Friend WithEvents TimerLado1 As Timer
    Friend WithEvents TimerLado2 As Timer
    Friend WithEvents TimerLado3 As Timer

End Class
